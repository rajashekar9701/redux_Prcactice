import React from 'react'
export default function Headercomponent() {

  return (
    <div>

        <h1>Welcome </h1>
    </div>
  )
}
