import React, { useContext, useRef } from 'react'
import { logincontext } from '../App'

export default function Logincomponent() {




  return (
    <div>

        <label>Enter UserName:</label>
        <input type="text" /> <br/>


        <label>Enter Password</label>
        <input type="password" /> <br></br>
 

            <button >Login</button>
     </div>
  )
}
