import logo from './logo.svg';
import './App.css';
import HeaderAuth from './Authentication/Header';
import Auth from './Authentication/Authentication';

import UserProfile from './Authentication/User.profile';
function App() {
  return (
    <div className="App">
     <HeaderAuth></HeaderAuth>
         <Auth></Auth>
         <UserProfile></UserProfile>
    </div>
  );
}

export default App;
